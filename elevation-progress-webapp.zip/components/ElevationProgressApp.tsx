"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";

type Region = {
  id: string;
  name: string;
  x: number; // 0..1
  y: number; // 0..1
  w: number; // 0..1
  h: number; // 0..1
  percent: number; // 0..100
  status: "not started" | "in progress" | "blocked" | "complete";
  notes?: string;
  color?: string;
};

const uid = () => Math.random().toString(36).slice(2, 9);
const clamp = (v: number, min = 0, max = 1) => Math.max(min, Math.min(max, v));

const statusColor = (r: Region) => {
  if (r.color) return r.color;
  switch (r.status) {
    case "complete": return "rgba(34,197,94,0.45)"; // green
    case "in progress": return "rgba(234,179,8,0.45)"; // amber
    case "blocked": return "rgba(239,68,68,0.45)"; // red
    default: {
      const a = Math.min(0.6, 0.2 + r.percent / 160);
      return `rgba(59,130,246,${a})`; // blue variable alpha
    }
  }
};

function useLocalStorage<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(value)); } catch {} }, [key, value]);
  return [value, setValue] as const;
}

async function grabCanvas(node: HTMLElement) {
  const mod: any = await import("html2canvas");
  const canvas = await mod.default(node, { backgroundColor: null, scale: 2 });
  return canvas as HTMLCanvasElement;
}

export default function ElevationProgressApp() {
  const [imgSrc, setImgSrc] = useLocalStorage<string | null>("ep_img", null);
  const [regions, setRegions] = useLocalStorage<Region[]>("ep_regions", []);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);

  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [ghost, setGhost] = useState<Region | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef<{ x: number; y: number } | null>(null);

  const selected = useMemo(() => regions.find(r => r.id === selectedId) || null, [regions, selectedId]);

  const onUpload = async (file: File | null) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setImgSrc(reader.result as string);
    reader.readAsDataURL(file);
  };

  const getBounds = () => wrapRef.current?.getBoundingClientRect();
  const toFrac = (clientX: number, clientY: number) => {
    const rect = getBounds();
    if (!rect) return { fx: 0, fy: 0 };
    const x = clamp((clientX - rect.left) / rect.width);
    const y = clamp((clientY - rect.top) / rect.height);
    return { fx: x, fy: y };
  };

  const onPointerDown = (e: React.PointerEvent) => {
    if (!imgSrc) return;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    const { fx, fy } = toFrac(e.clientX, e.clientY);
    dragStart.current = { x: fx, y: fy };
    setGhost({ id: "ghost", name: "", x: fx, y: fy, w: 0, h: 0, percent: 0, status: "not started" });
    setIsDragging(true);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!isDragging || !ghost) return;
    const { fx, fy } = toFrac(e.clientX, e.clientY);
    const x0 = Math.min(dragStart.current!.x, fx);
    const y0 = Math.min(dragStart.current!.y, fy);
    const w = Math.abs(fx - dragStart.current!.x);
    const h = Math.abs(fy - dragStart.current!.y);
    setGhost({ ...ghost, x: x0, y: y0, w, h });
  };

  const onPointerUp = () => {
    if (!isDragging || !ghost) return;
    setIsDragging(false);
    dragStart.current = null;
    if (ghost.w < 0.01 || ghost.h < 0.01) { setGhost(null); return; }
    const r: Region = { ...ghost, id: uid(), name: `Area ${regions.length + 1}` };
    setRegions([...regions, r]);
    setSelectedId(r.id);
    setGhost(null);
  };

  const updateRegion = (id: string, patch: Partial<Region>) => setRegions(prev => prev.map(r => r.id === id ? { ...r, ...patch } : r));
  const deleteRegion = (id: string) => { setRegions(prev => prev.filter(r => r.id !== id)); if (selectedId === id) setSelectedId(null); };

  const exportSnapshot = async () => {
    if (!wrapRef.current) return;
    const canvas = await grabCanvas(wrapRef.current);
    const link = document.createElement("a");
    link.href = canvas.toDataURL("image/png");
    link.download = `elevation-progress-${new Date().toISOString().slice(0,10)}.png`;
    link.click();
  };

  const totalPercent = useMemo(() => {
    if (regions.length === 0) return 0;
    const sum = regions.reduce((a, r) => a + r.percent, 0);
    return Math.round((sum / regions.length) * 10) / 10;
  }, [regions]);

  return (
    <div className="min-h-screen w-full bg-gray-50 p-4 md:p-6">
      <div className="mx-auto max-w-6xl">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <h1 className="text-2xl font-semibold">Elevation Progress Markup</h1>
          <div className="flex flex-wrap items-center gap-2">
            <label className="inline-flex items-center gap-2">
              <input type="file" accept="image/*,application/pdf" className="hidden" onChange={async (e) => {
                const f = e.target.files?.[0] || null;
                if (!f) return;
                if (f.type === "application/pdf") alert("Tip: export the PDF page as an image (PNG/JPG) first.");
                await onUpload(f);
              }} />
              <span className="inline-flex items-center rounded-md border px-3 py-2 text-sm bg-white cursor-pointer">Upload drawing</span>
            </label>
            <button onClick={() => setZoom(z => Math.max(0.25, z - 0.1))} className="rounded-md border px-3 py-2 text-sm bg-white">Zoom -</button>
            <button onClick={() => setZoom(z => Math.min(4, z + 0.1))} className="rounded-md border px-3 py-2 text-sm bg-white">Zoom +</button>
            <button onClick={exportSnapshot} className="rounded-md border px-3 py-2 text-sm bg-white">Export PNG</button>
            <button onClick={() => { if (confirm("Clear drawing and regions?")) { setImgSrc(null); setRegions([]); setSelectedId(null);} }} className="rounded-md border px-3 py-2 text-sm bg-white">Clear</button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 rounded-xl border bg-white">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <div className="font-medium">Drawing</div>
              <div className="text-sm text-gray-600">Overall: {totalPercent}%</div>
            </div>
            <div className="p-3">
              <div className="relative w-full aspect-[3/2] bg-white rounded-xl border overflow-hidden">
                <div
                  ref={wrapRef}
                  onPointerDown={onPointerDown}
                  onPointerMove={onPointerMove}
                  onPointerUp={onPointerUp}
                  className="relative h-full w-full"
                  style={{ touchAction: "none" }}
                >
                  {imgSrc ? (
                    <img src={imgSrc} alt="Elevation" className="absolute inset-0 h-full w-full object-contain select-none" style={{ transform: `scale(${zoom})`, transformOrigin: "center" }} />
                  ) : (
                    <div className="absolute inset-0 grid place-items-center text-gray-400 text-sm">
                      <div className="text-center">
                        <p className="mb-1">Upload an elevation image to get started</p>
                        <img src="/placeholder.png" className="mx-auto opacity-40 w-24" alt="placeholder" />
                      </div>
                    </div>
                  )}

                  {regions.map(r => (
                    <div
                      key={r.id}
                      className={`absolute border-2 ${selectedId === r.id ? "border-blue-600" : "border-blue-300"} rounded-md cursor-pointer`}
                      style={{
                        left: f"{r.x * 100}%",
                        top: f"{r.y * 100}%",
                        width: f"{r.w * 100}%",
                        height: f"{r.h * 100}%",
                        background: statusColor(r),
                        transform: `scale(${zoom})`, transformOrigin: "top left",
                      } as React.CSSProperties}
                      onClick={(e) => { e.stopPropagation(); setSelectedId(r.id); }}
                    >
                      <div className="absolute -top-6 left-0 text-xs bg-black/70 text-white rounded px-1">
                        {r.name} • {r.percent}%
                      </div>
                    </div>
                  ))}

                  {ghost && (
                    <div className="absolute border-2 border-dashed border-blue-500 bg-blue-500/20 rounded-md"
                      style={{ left: f"{ghost.x * 100}%", top: f"{ghost.y * 100}%", width: f"{ghost.w * 100}%", height: f"{ghost.h * 100}%", transform: `scale(${zoom})`, transformOrigin: "top left" }}
                    />
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-xl border bg-white">
            <div className="px-4 py-3 border-b">
              <div className="font-medium">Inspector</div>
              <p className="text-xs text-gray-500">Click–drag on the drawing to add an area. Select to edit.</p>
            </div>
            <div className="p-4 space-y-3">
              <button className="w-full rounded-md border px-3 py-2 text-sm bg-white" onClick={() => {
                const r: Region = { id: uid(), name: `Area ${regions.length + 1}`, x: 0.1, y: 0.1, w: 0.2, h: 0.1, percent: 0, status: "not started" };
                setRegions([...regions, r]); setSelectedId(r.id);
              }}>Add area</button>

              <div className="max-h-[420px] overflow-auto space-y-3">
                {regions.length === 0 && <div className="text-sm text-gray-500">No areas yet.</div>}
                {regions.map(r => (
                  <div key={r.id} className={`rounded-lg border p-3 ${selectedId === r.id ? "ring-2 ring-blue-500" : ""}`}>
                    <div className="flex items-center gap-2">
                      <input className="w-full border rounded px-2 py-1 text-sm" value={r.name} onChange={e => updateRegion(r.id, { name: e.target.value })} />
                      <button className="text-xs text-red-600" onClick={() => deleteRegion(r.id)}>Delete</button>
                    </div>
                    <div className="mt-2 text-xs text-gray-500">{Math.round(r.w*100)}% × {Math.round(r.h*100)}% of drawing</div>
                    <div className="mt-2">
                      <label className="text-xs block">Progress: {r.percent}%</label>
                      <input type="range" min={0} max={100} value={r.percent} onChange={e => updateRegion(r.id, { percent: Number(e.target.value), status: Number(e.target.value) == 100 ? "complete" : (r.status == "complete" ? "in progress" : r.status) })} className="w-full" />
                    </div>
                    <div className="mt-2">
                      <label className="text-xs block">Status</label>
                      <select className="w-full border rounded px-2 py-1 text-sm" value={r.status} onChange={e => updateRegion(r.id, { status: e.target.value as Region["status"] })}>
                        <option value="not started">Not started</option>
                        <option value="in progress">In progress</option>
                        <option value="blocked">Blocked</option>
                        <option value="complete">Complete</option>
                      </select>
                    </div>
                    <div className="mt-2">
                      <label className="text-xs block">Notes</label>
                      <textarea rows={3} className="w-full border rounded px-2 py-1 text-sm" value={r.notes || ""} onChange={e => updateRegion(r.id, { notes: e.target.value })} />
                    </div>
                    <div className="mt-2 text-xs"><span className="inline-block rounded px-2 py-1" style={{ background: statusColor(r) }}>Color preview</span></div>
                    <div className="mt-2"><button className="text-xs underline" onClick={() => setSelectedId(r.id)}>Select</button></div>

                  </div>
                ))}
              </div>

              {selected && (
                <div className="rounded-lg border p-3">
                  <div className="font-medium text-sm mb-2">Selected Area: {selected.name}</div>
                  <div className="grid grid-cols-2 gap-2">
                    <label className="text-xs">X (%)<input type="number" className="w-full border rounded px-2 py-1 text-sm" value={Math.round(selected.x*100)} onChange={e => updateRegion(selected.id, { x: clamp(Number(e.target.value)/100) })} /></label>
                    <label className="text-xs">Y (%)<input type="number" className="w-full border rounded px-2 py-1 text-sm" value={Math.round(selected.y*100)} onChange={e => updateRegion(selected.id, { y: clamp(Number(e.target.value)/100) })} /></label>
                    <label className="text-xs">W (%)<input type="number" className="w-full border rounded px-2 py-1 text-sm" value={Math.round(selected.w*100)} onChange={e => updateRegion(selected.id, { w: clamp(Number(e.target.value)/100) })} /></label>
                    <label className="text-xs">H (%)<input type="number" className="w-full border rounded px-2 py-1 text-sm" value={Math.round(selected.h*100)} onChange={e => updateRegion(selected.id, { h: clamp(Number(e.target.value)/100) })} /></label>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <p className="mt-4 text-xs text-gray-500">Data is stored locally in your browser (localStorage). Export PNG for reports. For multi-user sync, add a backend later.</p>
      </div>
    </div>
  );
}
