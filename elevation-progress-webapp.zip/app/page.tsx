import dynamic from "next/dynamic";

// html2canvas uses window, so load component on client only
const ElevationProgressApp = dynamic(() => import("../components/ElevationProgressApp"), { ssr: false });

export default function Page() {
  return <ElevationProgressApp />;
}
