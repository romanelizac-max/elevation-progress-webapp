import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Elevation Progress Markup",
  description: "Overlay regions and track progress on elevation drawings",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
